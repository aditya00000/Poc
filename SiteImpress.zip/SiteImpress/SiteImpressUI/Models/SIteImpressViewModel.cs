﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SiteImpressUI.Models
{
    public class SIteImpressViewModel
    {
        public double? SiteId { get; set; }
        public DateTime? Hitdate { get; set; }

        public SIteImpressViewModel()
        {
            records = new List<SIteImpressViewModel>();
        }

        public List<SIteImpressViewModel> records { get; set; }
    }
}
