﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SiteImpressUI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace SiteImpressUI.Controllers
{
    public class SiteImpressController : Controller
    {
        //public const string apiBaseUrl = appSettings.GetValue<string>("apiBaseUrl");
        public async Task<IActionResult> Index()
        {
            using (HttpClient client = new HttpClient())
            {
               // StringContent content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");
                StringContent content = new StringContent("");
                string endpoint = "https://localhost:44362" + "/SiteImpress";
                //using (var Response = await client.GetAsync(endpoint))
                //{
                //    if (Response.StatusCode == System.Net.HttpStatusCode.OK)
                //    {
                //        //TempData["Profile"] = JsonConvert.SerializeObject(user);
                //        return RedirectToAction("Index");
                //    }
                //    else if (Response.StatusCode == System.Net.HttpStatusCode.Conflict)
                //    {
                //        ModelState.Clear();
                //        ModelState.AddModelError("Username", "Username Already Exist");
                //        return View();
                //    }
                //    else
                //    {
                //        return View();
                //    }
                //}
                HttpClientHandler handler = new HttpClientHandler();

                using (HttpClient httpClient = new HttpClient(handler))
                {
                    using (HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, endpoint))
                    {
                        request.Headers.Accept.Clear();
                        request.Headers.Add("ApiKey", "SiteImpress_ApiKey");
                        var response = await httpClient.SendAsync(request);
                        var responseContent = await response.Content.ReadAsStringAsync();
                        var data = new SIteImpressViewModel();
                        data.records = JsonConvert.DeserializeObject<List<SIteImpressViewModel>>(responseContent);
                        //return RedirectToAction("Index");

                        return View(data);

                        //string requestContent = (request.Content != null) ? await request.Content.ReadAsStringAsync() : "";
                        //return responseContent;
                    }
                }

            }
            return View();
        }
    }
}
