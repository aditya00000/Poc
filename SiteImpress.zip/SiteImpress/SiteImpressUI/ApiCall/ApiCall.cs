﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace SiteImpressUI.ApiCall
{
    public class ApiCall
    {

        //[HttpGet]
        //public async Task<string> GetDataAsync(string method, GetRequestModel[] param)
        //{
        //    //using (HttpClient client = new HttpClient())
        //    //{
        //    //    StringContent content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");
        //    //    string endpoint = apiBaseUrl + "/login";

        //    //    using (var Response = await client.PostAsync(endpoint, content))
        //    //    {
        //    //        if (Response.StatusCode == System.Net.HttpStatusCode.OK)
        //    //        {
        //    //            TempData["Profile"] = JsonConvert.SerializeObject(user);

        //    //            return RedirectToAction("Profile");

        //    //        }
        //    //        else
        //    //        {
        //    //            ModelState.Clear();
        //    //            ModelState.AddModelError(string.Empty, "Username or Password is Incorrect");
        //    //            return View();

        //    //        }

        //    //    }
        //    //}

        //}
    }
    public class GetRequestModel
    {
        public string paramname { get; set; }
        public string paramvalue { get; set; }
    }
}
