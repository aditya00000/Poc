﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SiteImpress.Attributes;
using SiteImpress.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SiteImpress.Controllers
{
    [ApiKey]
    [ApiController]
    [Route("[controller]")]
    public class SiteImpressController : ControllerBase
    {
        [HttpGet]
        public IEnumerable<object> Get()
        {
            using (var context = new SampleContext())
            {
                //List<SiteImpressionViewModel> returnmodel = new List<SiteImpressionViewModel>();
               return context.SiteImpressions.Select(s => new { s.SiteId, s.Hitdate }).Take(10).ToList();
            }
        }

        //[HttpGet]
        //public IEnumerable<object> Get(double id)
        //{
        //    using (var context = new SampleContext())
        //    {
        //        //List<SiteImpressionViewModel> returnmodel = new List<SiteImpressionViewModel>();
        //        return context.SiteImpressions.Where(s => s.SiteId == id).ToList();
        //    }
        //}

        [HttpDelete]
        public void Delete(string sampleId)
        {
            using (var context = new SampleContext())
            {
                var record = context.SiteImpressions.Where(s => s.SampleId == sampleId).FirstOrDefault();
                context.SiteImpressions.Remove(record);
                context.SaveChanges();
               // return context.SiteImpressions.ToList();
            }
        }
        [HttpPost]
        public void Update(string sampleId, double impressionData)
        {
            using (var context = new SampleContext())
            {
                var record = context.SiteImpressions.Where(s => s.SampleId == sampleId).FirstOrDefault();
                record.ImpressionData = impressionData;
                context.SaveChanges();
            }
        }
    }
}
