﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SiteImpress.Models
{
    public partial class SiteImpression
    {
        public string SampleId { get; set; }
        public double? SiteId { get; set; }
        public DateTime? Hitdate { get; set; }
        public double? Bannerid { get; set; }
        public double? BannersiteId { get; set; }
        public double? CreativeId { get; set; }
        public double? PlacementId { get; set; }
        public string DeviceType { get; set; }
        public string Browser { get; set; }
        public string Vendor { get; set; }
        public string Os { get; set; }
        public double? ImpressionData { get; set; }
    }
}
