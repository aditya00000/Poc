﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SiteImpress.Models
{
    public class SiteImpressionViewModel
    {
        public SiteImpressionViewModel()
        {
            records = new List<SiteImpressionViewModel>();
        }
        public double? SiteId { get; set; }
        public DateTime? Hitdate { get; set; }

        public List<SiteImpressionViewModel> records { get; set; }
    }
}
